from django.apps import AppConfig

class FleetFindAppConfig(AppConfig):
    """App configuration for fleetfind."""
    name = 'fleetfind'
    default_auto_field = 'django.db.models.AutoField'